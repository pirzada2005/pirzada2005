let count = 0;
const counterDisplay = document.getElementById('counter');
const container = document.getElementById('container');

function incrementCounter() {
    count++;
    counterDisplay.innerText = count;
}

function resetCounter() {
    count = 0;
    counterDisplay.innerText = count;
}

function toggleNightMode() {
    container.classList.toggle('night-mode');
    if (container.classList.contains('night-mode')) {
        document.body.style.backgroundColor = '#222';
        document.body.style.color = '#fff';
    } else {
        document.body.style.backgroundColor = '#f2f2f2';
        document.body.style.color = '#333';
    }
}
